#include <stdio.h>

int main (){
    int num[5];

    printf("Informe o valor da posição 0: ");
    scanf("%d", &num[0]);

    printf("O valor informado foi %d", num[0]);

    return 0;
}
