#include <stdio.h>
#include <stdlib.h>

struct produto {
    char *nome;
    int quantidade;
    float preco;
};

int main(){

    struct produto listaProdutos[5];

    int i;
    for (i = 0; i < 5; i++) {
        listaProdutos[i].nome = malloc(50);

        printf("Informe o nome do produto: ");
        scanf(" %[^\n]", listaProdutos[i].nome);



    }

    return 0;
}