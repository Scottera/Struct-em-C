#include <stdio.h>
#include <stdlib.h>

typedef struct Item{
    int valor;
    struct Item* proximo;
} Item;


Item* criarItem(int valor) {
    Item* novoItem = malloc(sizeof(Item));
    novoItem->valor = valor;
    novoItem->proximo = NULL;

    return novoItem;
}

int main() {
    Item *primeiro = NULL;
    primeiro = malloc(sizeof(Item));

    primeiro->valor = 5;
    primeiro->proximo = NULL;

    Item* segundo = malloc(sizeof(Item));
    segundo->valor = 3;
    segundo->proximo = NULL;

    primeiro->proximo = segundo;

    Item* item = primeiro;
    while (item != NULL) {
        printf("%d \n", item->valor);
        item = item->proximo;
    }

    return 0;
}
