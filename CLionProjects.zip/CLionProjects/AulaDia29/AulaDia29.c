#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct aluno {
    char *nome;
    float nota;
} Aluno;

typedef struct Item {
    Aluno valor;
    struct  Item* proximo;
} Item;

Item* criarItem(Aluno valor) {
    Item * novoItem = malloc(sizeof(Item));
    novoItem->valor = valor;
    novoItem->proximo = NULL;

    return novoItem;
}

void adicionarItem(Item** inicio, Aluno valor){ //Percorre toda a lista até encontrar o último elemento que seja vazio
    Item* novoItem = criarItem(valor);

    if (*inicio == NULL) {
        *inicio = novoItem;
    } else {
        Item* atual = *inicio;
        while (atual->proximo != NULL) {
            atual = atual->proximo;
        }
        atual->proximo = novoItem;
    }
}

void exibirLista(Item** inicio) { //void porque nao retorna nada
    Item* item = *inicio;
    while (item != NULL) {
        Aluno aluno = item->valor; //-> porque é ponteiro (Item)
        printf("Nome: %s \n", aluno.nome);
        printf("Nota: %.1f \n", aluno.nota);

        item = item->proximo;

    }
}

Aluno criarAluno() {
    Aluno aluno;
    aluno.nome = malloc(50);

    printf("Informe o nome do aluno: ");
    scanf(" %[^\n]", aluno.nome);

    printf("Informe a nota do aluno: ");
    scanf("%f", &aluno.nota);

    return aluno;
}

int main() {
    char continuar = 'N';
    Item * inicio = NULL;
    do {                            //Garantir que seja executado pelo menos uma vez
        Aluno aluno = criarAluno();
        adicionarItem(&inicio, aluno);

        printf("Deseja continuar? (S/N) ");
        scanf(" %c", &continuar);

    } while (toupper(continuar) == 'S');

    exibirLista(&inicio);

    return 0;
}